/**
 * Controller for the tablet form-factor detail (child) view
 * 
 * @class Controllers.tablet.detail
 * @uses core
 */
var APP = require("core");

$.NavigationBar.setBackgroundColor(APP.Settings.colors.primary);