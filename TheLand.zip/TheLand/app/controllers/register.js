var Cloud = require("ti.cloud");

var APP = require("core");
var CONFIG = arguments[0] || {};

var init = function() {
	$.NavigationBar.setBackgroundColor(APP.Settings.colors.primary);
	$.NavigationBar.showBack(function(_event) {
		APP.removeChild();
	});

	$.reg.addEventListener("click", function() {

		Cloud.Users.create({
			email: $.email,
			first_name: $.first_name.value,
			last_name: $.last_name.value,
			password: $.pass.value,
			password_confirmation: $.pass.value
		}, function(e) {
			if(e.success) {
				var user = e.users[0];
				alert('Welcome:\n' + $.first_name.value + ' ' + $.last_name.value +
					'\nRegistration completed!');
				Ti.App.Properties.setString("sessionId", Cloud.sessionId);

				//Ti.App.Properties.setString('sessionId', '');

				APP.removeAllChildren();

			} else {
				alert('Error:\n' + ((e.error && e.message) || JSON.stringify(e)));
			}

		});

	});
};

init();