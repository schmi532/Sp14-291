var Cloud = require("ti.cloud");

var APP = require("core");
var CONFIG = arguments[0] || {};

var init = function() {
	$.NavigationBar.setBackgroundColor(APP.Settings.colors.primary);

	if(CONFIG.isChild === true) {
		$.NavigationBar.showBack(function(_event) {
			APP.removeChild();
		});
	} else {
		if(APP.Settings.useSlideMenu) {
			$.NavigationBar.showMenu(function(_event) {
				APP.toggleMenu;
			});
		} else {
			$.NavigationBar.showSettings(function(_event) {
				APP.openSettings();
			});
		}
	}
};

var doLogin = function() {

	$.submit.addEventListener("click", function() {
		Cloud.Users.login({
			login: $.username.value,
			password: $.password.value
		}, function(e) {
			if(e.success) {
				var user = e.users[0];

				alert("Welcome Back!");
				Alloy.Globals.swipeEnabled = true;
				APP.removeChild();

				//Ti.App.Properties.setString("sessionId", Cloud.sessionId);
				//var index = Alloy.createController('index').getView();
				//index.open();
				//Ti.App.Properties.setString('sessionId', '');

			} else {
				alert('Error: ' + ((e.error && e.message) || JSON.stringify(e)));
			}
		});

	});

	$.reg.addEventListener("click", function() {
		APP.addChild('register');
	});

};

init();
doLogin();