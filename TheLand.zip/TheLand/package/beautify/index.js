module.exports = require('./beautify').js_beautify;
