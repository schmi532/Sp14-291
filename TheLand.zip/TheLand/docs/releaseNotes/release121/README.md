Change Log
========================

This document describes the high-level changes made for each version. For a complete list of changes, please refer to the [ChariTi GitHub repository](http://github.com/mcongrove/ChariTi/).

v 1.2.1 (11-18-2013)
--------------------
*	Using native toast notifications for Android
*	Fixed detail navigation for Android
*	Fixed podcast auto-play duplication
*	Fixed slide menu headers on Android
*	Fixed application update process
*	Fixed over-the-air updates
*	Improved framework version detection