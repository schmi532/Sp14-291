Change Log
========================

This document describes the high-level changes made for each version. For a complete list of changes, please refer to the [ChariTi GitHub repository](http://github.com/mcongrove/ChariTi/).

v 1.0.0 (01-12-2013)
------------------
*	Initial release
*	Supports iPhone, iPad (zoomed mode)