var APP = require("core");

var SOCIAL = require("dk.napp.social");

exports.twitterSupported = SOCIAL.isTwitterSupported();

exports.emailSupported = Ti.UI.createEmailDialog().isSupported();

exports.activitySupported = SOCIAL.isActivityViewSupported();

exports.email = function(_url) {
    if (exports.emailSupported) {
        var email = Ti.UI.createEmailDialog();
        email.html = true;
        email.messageBody = APP.Settings.share + "<br /><br /><a href='" + _url + "'>" + _url + "</a>";
        email.open();
    }
};

exports.twitter = function(_url) {
    exports.twitterSupported && SOCIAL.twitter({
        text: APP.Settings.share,
        url: _url
    });
};

exports.shareActivityView = function(_url, _view) {
    var dialog = Ti.UI.createOptionDialog({
        options: [ "Share", "Open in Safari", "Cancel" ],
        cancel: 2,
        selectedIndex: 2
    });
    dialog.addEventListener("click", function(_event) {
        switch (_event.index) {
          case 0:
            "IPAD" == APP.Device.name ? SOCIAL.activityPopover({
                text: APP.Settings.share + " " + _url,
                removeIcons: "print,copy,contact,camera,weibo",
                view: _view
            }) : SOCIAL.activityView({
                text: APP.Settings.share + " " + _url,
                removeIcons: "print,copy,contact,camera,weibo"
            });
            break;

          case 1:
            Ti.Platform.openURL(_url);
        }
    });
    void 0 === _view ? dialog.show() : dialog.show({
        view: _view
    });
};

exports.share = function(_url, _view) {
    if (exports.activitySupported) exports.shareActivityView(_url, _view); else {
        var options = [];
        var mapping = [];
        if (exports.twitterSupported) {
            options.push("Share via Twitter");
            mapping.push("twitter");
        }
        if (exports.emailSupported) {
            options.push("Share via E-Mail");
            mapping.push("email");
        }
        options.push("Open in Safari");
        mapping.push("browser");
        options.push("Cancel");
        mapping.push("cancel");
        var dialog = Ti.UI.createOptionDialog({
            options: options,
            cancel: options.length - 1,
            selectedIndex: options.length - 1
        });
        dialog.addEventListener("click", function(_event) {
            switch (mapping[_event.index]) {
              case "twitter":
                exports.twitter(_url);
                break;

              case "email":
                exports.email(_url);
                break;

              case "browser":
                Ti.Platform.openURL(_url);
            }
        });
        void 0 === _view ? dialog.show() : dialog.show({
            view: _view
        });
    }
};