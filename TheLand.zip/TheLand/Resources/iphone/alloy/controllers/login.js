function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "login";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.wrapper = Ti.UI.createView({
        id: "wrapper",
        name: "Text"
    });
    $.__views.wrapper && $.addTopLevelView($.__views.wrapper);
    $.__views.NavigationBar = Alloy.createWidget("com.mcongrove.navigationBar", "widget", {
        id: "NavigationBar",
        img: "data/logo.png",
        __parentSymbol: $.__views.wrapper
    });
    $.__views.NavigationBar.setParent($.__views.wrapper);
    $.__views.container = Ti.UI.createScrollView({
        scrollsToTop: false,
        top: "0dp",
        backgroundColor: "#FFF",
        layout: "vertical",
        showVerticalScrollIndicator: true,
        id: "container"
    });
    $.__views.wrapper.add($.__views.container);
    $.__views.username = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "username",
        hintText: "username"
    });
    $.__views.container.add($.__views.username);
    $.__views.password = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "password",
        hintText: "password",
        passwordMask: "true"
    });
    $.__views.container.add($.__views.password);
    $.__views.submit = Ti.UI.createButton({
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        title: "Login",
        id: "submit"
    });
    $.__views.container.add($.__views.submit);
    $.__views.reg = Ti.UI.createButton({
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        title: "New User?",
        id: "reg"
    });
    $.__views.container.add($.__views.reg);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var Cloud = require("ti.cloud");
    var APP = require("core");
    var CONFIG = arguments[0] || {};
    var init = function() {
        $.NavigationBar.setBackgroundColor(APP.Settings.colors.primary);
        true === CONFIG.isChild ? $.NavigationBar.showBack(function() {
            APP.removeChild();
        }) : APP.Settings.useSlideMenu ? $.NavigationBar.showMenu(function() {
            APP.toggleMenu;
        }) : $.NavigationBar.showSettings(function() {
            APP.openSettings();
        });
    };
    var doLogin = function() {
        $.submit.addEventListener("click", function() {
            Cloud.Users.login({
                login: $.username.value,
                password: $.password.value
            }, function(e) {
                if (e.success) {
                    e.users[0];
                    alert("Welcome Back!");
                    Alloy.Globals.swipeEnabled = true;
                    APP.removeChild();
                } else alert("Error: " + (e.error && e.message || JSON.stringify(e)));
            });
        });
        $.reg.addEventListener("click", function() {
            APP.addChild("register");
        });
    };
    init();
    doLogin();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;