function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "register";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.wrapper = Ti.UI.createView({
        id: "wrapper",
        name: "Text"
    });
    $.__views.wrapper && $.addTopLevelView($.__views.wrapper);
    $.__views.NavigationBar = Alloy.createWidget("com.mcongrove.navigationBar", "widget", {
        id: "NavigationBar",
        img: "data/logo.png",
        __parentSymbol: $.__views.wrapper
    });
    $.__views.NavigationBar.setParent($.__views.wrapper);
    $.__views.container = Ti.UI.createScrollView({
        scrollsToTop: false,
        top: "0dp",
        backgroundColor: "#FFF",
        layout: "vertical",
        showVerticalScrollIndicator: true,
        id: "container"
    });
    $.__views.wrapper.add($.__views.container);
    $.__views.email = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "email",
        hintText: "email@email.com"
    });
    $.__views.container.add($.__views.email);
    $.__views.first_name = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "first_name",
        hintText: "first name"
    });
    $.__views.container.add($.__views.first_name);
    $.__views.last_name = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "last_name",
        hintText: "last name"
    });
    $.__views.container.add($.__views.last_name);
    $.__views.pass = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "pass",
        hintText: "password",
        passwordMask: "true"
    });
    $.__views.container.add($.__views.pass);
    $.__views.reg = Ti.UI.createButton({
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        title: "Register",
        id: "reg"
    });
    $.__views.container.add($.__views.reg);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var Cloud = require("ti.cloud");
    var APP = require("core");
    arguments[0] || {};
    var init = function() {
        $.NavigationBar.setBackgroundColor(APP.Settings.colors.primary);
        $.NavigationBar.showBack(function() {
            APP.removeChild();
        });
        $.reg.addEventListener("click", function() {
            Cloud.Users.create({
                email: $.email,
                first_name: $.first_name.value,
                last_name: $.last_name.value,
                password: $.pass.value,
                password_confirmation: $.pass.value
            }, function(e) {
                if (e.success) {
                    e.users[0];
                    alert("Welcome:\n" + $.first_name.value + " " + $.last_name.value + "\nRegistration completed!");
                    Ti.App.Properties.setString("sessionId", Cloud.sessionId);
                    APP.removeAllChildren();
                } else alert("Error:\n" + (e.error && e.message || JSON.stringify(e)));
            });
        });
    };
    init();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;