function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "com.mcongrove.slideMenu/" + s : s.substring(0, index) + "/com.mcongrove.slideMenu/" + s.substring(index + 1);
    return path;
}

module.exports = [ {
    isApi: true,
    priority: 1000.0002,
    key: "TableView",
    style: {
        scrollsToTop: false
    }
}, {
    isApi: true,
    priority: 1000.0003,
    key: "WebView",
    style: {
        scrollsToTop: false
    }
}, {
    isApi: true,
    priority: 1000.0004,
    key: "TextArea",
    style: {
        scrollsToTop: false
    }
}, {
    isApi: true,
    priority: 1000.0005,
    key: "ScrollView",
    style: {
        scrollsToTop: false
    }
}, {
    isApi: true,
    priority: 1000.0006,
    key: "TextField",
    style: {
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp"
    }
}, {
    isApi: true,
    priority: 1000.0007,
    key: "Button",
    style: {
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5"
    }
}, {
    isApi: true,
    priority: 1101.0001,
    key: "Window",
    style: {
        statusBarStyle: Ti.UI.iPhone.StatusBar.DEFAULT
    }
}, {
    isId: true,
    priority: 100000.0023,
    key: "Wrapper",
    style: {
        width: "200dp",
        top: "0dp",
        left: "-200dp",
        backgroundColor: "#000"
    }
}, {
    isId: true,
    priority: 100000.0024,
    key: "Nodes",
    style: {
        top: "0dp",
        backgroundColor: "#111",
        separatorColor: "#222",
        separatorStyle: Ti.UI.iPhone.TableViewSeparatorStyle.SINGLE_LINE
    }
} ];