var Cloud = require("ti.cloud");

$.submit.addEventListener("click", function() {
	Cloud.Users.login({
		login: $.username.value,
		password: $.password.value
	}, function(e) {
		if(e.success) {
			var user = e.users[0];

			alert("Success!");

			Ti.App.Properties.setString("sessionId", Cloud.sessionId);
			APP.init();
			//Ti.App.Properties.setString('sessionId', '');

		} else {
			alert('Error: ' + ((e.error && e.message) || JSON.stringify(e)));
		}
	});

});

$.reg.addEventListener("click", function() {
	var register = Alloy.createController('register').getView();
	register.open();
});