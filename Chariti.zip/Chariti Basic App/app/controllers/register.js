var Cloud = require("ti.cloud");

$.reg.addEventListener("click", function() {

	Cloud.Users.create({
		email: $.email,
		first_name: $.first_name.value,
		last_name: $.last_name.value,
		password: $.pass.value,
		password_confirmation: $.pass.value
	}, function(e) {
		if(e.success) {
			var user = e.users[0];
			alert('Welcome:\n' + $.first_name.value + ' ' + $.last_name.value +
				'\nRegistration completed');
			Ti.App.Properties.setString("sessionId", Cloud.sessionId);

			/*var APP = require("core");

			// Make sure we always have a reference to global elements throughout the APP singleton
			APP.MainWindow = $.MainWindow;
			APP.GlobalWrapper = $.GlobalWrapper;
			APP.ContentWrapper = $.ContentWrapper;
			APP.Tabs = $.Tabs;
			APP.SlideMenu = $.SlideMenu;

			APP.init();*/

			Ti.App.Properties.setString('sessionId', '');

		} else {
			alert('Error:\n' + ((e.error && e.message) || JSON.stringify(e)));
		}

	});

});