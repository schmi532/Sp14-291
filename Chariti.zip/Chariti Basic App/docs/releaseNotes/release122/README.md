Change Log
========================

This document describes the high-level changes made for each version. For a complete list of changes, please refer to the [ChariTi GitHub repository](http://github.com/mcongrove/ChariTi/).

v 1.2.2 (11-??-2013)
--------------------
*	StatusBar styling now based on themes
*	Added menu header for Settings if menu headers used elsewhere
*	Better color determinations
*	Easier-to-use map settings
*	Fixed missing toolbar on web view
*	Fixed UI problems for PDF screen
*	Fixed UI inconsistencies for Settings screen
*	Fixed file misnaming, misreferences
*	Widgets are now self-contained