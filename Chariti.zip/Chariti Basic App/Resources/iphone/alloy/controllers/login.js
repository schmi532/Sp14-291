function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "login";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.logIn = Ti.UI.createWindow({
        statusBarStyle: Ti.UI.iPhone.StatusBar.DEFAULT,
        id: "logIn",
        layout: "vertial",
        backgroundColor: "white"
    });
    $.__views.logIn && $.addTopLevelView($.__views.logIn);
    $.__views.__alloyId1 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId1"
    });
    $.__views.logIn.add($.__views.__alloyId1);
    $.__views.username = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "username",
        hintText: "username"
    });
    $.__views.__alloyId1.add($.__views.username);
    $.__views.password = Ti.UI.createTextField({
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        width: Ti.UI.FILL,
        left: "25dp",
        right: "25dp",
        top: "25dp",
        id: "password",
        hintText: "password",
        passwordMask: "true"
    });
    $.__views.__alloyId1.add($.__views.password);
    $.__views.submit = Ti.UI.createButton({
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        title: "Login",
        id: "submit"
    });
    $.__views.__alloyId1.add($.__views.submit);
    $.__views.reg = Ti.UI.createButton({
        width: "100dp",
        top: "10dp",
        backgroundColor: "gray",
        borderColor: "black",
        borderRadius: "5",
        title: "New User?",
        id: "reg"
    });
    $.__views.__alloyId1.add($.__views.reg);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var Cloud = require("ti.cloud");
    $.submit.addEventListener("click", function() {
        Cloud.Users.login({
            login: $.username.value,
            password: $.password.value
        }, function(e) {
            if (e.success) {
                e.users[0];
                alert("Success!");
                Ti.App.Properties.setString("sessionId", Cloud.sessionId);
                APP.init();
            } else alert("Error: " + (e.error && e.message || JSON.stringify(e)));
        });
    });
    $.reg.addEventListener("click", function() {
        var register = Alloy.createController("register").getView();
        register.open();
    });
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;